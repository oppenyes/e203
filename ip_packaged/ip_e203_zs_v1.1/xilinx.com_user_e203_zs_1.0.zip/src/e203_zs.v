`timescale 1ns/1ps
`include "e203_defines.v"
//不包含时钟和复位ipip
module e203_zs
(
    input  wire                              clk_16M                       ,//GCLK-W19
    input  wire                              CLK32768KHZ                   ,//RTC_CLK-Y18

    input  wire                              fpga_rst                      ,//FPGA_RESET-T6
    input  wire                              mcu_rst                       ,//MCU_RESET-P20


  // Dedicated QSPI interface
    output wire                              qspi0_cs                      ,
    output wire                              qspi0_sck                     ,
    inout  wire        [   3: 0]             qspi0_dq                      ,
                           
  //gpioA
    inout  wire        [  31: 0]             gpioA                         ,//GPIOA00~GPIOA31

  //gpioB
    inout  wire        [  31: 0]             gpioB                         ,//GPIOB00~GPIOB31
  //////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////
  // AXI Read Address Channel
    output                                   expl_axi_arvalid              ,// AXI address valid
    input                                    expl_axi_arready              ,// AXI address ready
    output             [`E203_ADDR_SIZE-1: 0]expl_axi_araddr               ,// AXI address
    output             [   3: 0]             expl_axi_arcache              ,// AXI cache
    output             [   2: 0]             expl_axi_arprot               ,// AXI protection
    output             [   1: 0]             expl_axi_arlock               ,// AXI lock
    output             [   1: 0]             expl_axi_arburst              ,// AXI burst type
    output             [   3: 0]             expl_axi_arlen                ,// AXI burst length
    output             [   2: 0]             expl_axi_arsize               ,// AXI burst size
    
    // AXI Write Address Channel
    output                                   expl_axi_awvalid              ,// AXI write address valid
    input                                    expl_axi_awready              ,// AXI write address ready
    output             [`E203_ADDR_SIZE-1: 0]expl_axi_awaddr               ,// AXI write address
    output             [   3: 0]             expl_axi_awcache              ,// AXI write cache
    output             [   2: 0]             expl_axi_awprot               ,// AXI write protection
    output             [   1: 0]             expl_axi_awlock               ,// AXI write lock
    output             [   1: 0]             expl_axi_awburst              ,// AXI write burst type
    output             [   3: 0]             expl_axi_awlen                ,// AXI write burst length
    output             [   2: 0]             expl_axi_awsize               ,// AXI write burst size

    // AXI Read Data Channel
    input                                    expl_axi_rvalid               ,// AXI read valid
    output                                   expl_axi_rready               ,// AXI read ready
    input              [`E203_XLEN-1: 0]     expl_axi_rdata                ,// AXI read data
    input              [   1: 0]             expl_axi_rresp                ,// AXI read response
    input                                    expl_axi_rlast                ,// AXI read last

    // AXI Write Data Channel
    output                                   expl_axi_wvalid               ,// AXI write valid
    input                                    expl_axi_wready               ,// AXI write ready
    output             [`E203_XLEN-1: 0]     expl_axi_wdata                ,// AXI write data
    output             [(`E203_XLEN/8)-1: 0] expl_axi_wstrb                ,// AXI write strobe
    output                                   expl_axi_wlast                ,// AXI write last

    // AXI Write Response Channel
    input                                    expl_axi_bvalid               ,// AXI write response valid
    output                                   expl_axi_bready               ,// AXI write response ready
    input              [   1: 0]             expl_axi_bresp                ,// AXI write response
  // JD (used for JTAG connection)
    inout  wire                              mcu_TDO                       ,//MCU_TDO-N17
    inout  wire                              mcu_TCK                       ,//MCU_TCK-P15 
    inout  wire                              mcu_TDI                       ,//MCU_TDI-T18
    inout  wire                              mcu_TMS                       ,//MCU_TMS-P17
    // ck_rst = fpga_rst & mcu_rst;
    output                                   ck_rst                        ,//  assign ck_rst = fpga_rst & mcu_rst;
  //pmu_wakeup

    inout  wire                              pmu_paden                     ,//PMU_VDDPADEN-U15
    inout  wire                              pmu_padrst                    ,//PMU_VADDPARST_V15
    inout  wire                              mcu_wakeup                     //MCU_WAKE-N15
);

  // wire clk_out1;
  // wire mmcm_locked;

  // wire reset_periph;

  // wire ck_rst;
    assign                                   ck_rst                       = fpga_rst & mcu_rst;
  // All wires connected to the chip top
    wire                                     dut_clock                     ;
    wire                                     dut_reset                     ;

    wire                                     dut_io_pads_jtag_TCK_i_ival   ;
    wire                                     dut_io_pads_jtag_TMS_i_ival   ;
    wire                                     dut_io_pads_jtag_TMS_o_oval   ;
    wire                                     dut_io_pads_jtag_TMS_o_oe     ;
    wire                                     dut_io_pads_jtag_TMS_o_ie     ;
    wire                                     dut_io_pads_jtag_TMS_o_pue    ;
    wire                                     dut_io_pads_jtag_TMS_o_ds     ;
    wire                                     dut_io_pads_jtag_TDI_i_ival   ;
    wire                                     dut_io_pads_jtag_TDO_o_oval   ;
    wire                                     dut_io_pads_jtag_TDO_o_oe     ;

    wire               [32-1: 0]             dut_io_pads_gpioA_i_ival      ;
    wire               [32-1: 0]             dut_io_pads_gpioA_o_oval      ;
    wire               [32-1: 0]             dut_io_pads_gpioA_o_oe        ;

    wire               [32-1: 0]             dut_io_pads_gpioB_i_ival      ;
    wire               [32-1: 0]             dut_io_pads_gpioB_o_oval      ;
    wire               [32-1: 0]             dut_io_pads_gpioB_o_oe        ;

    wire                                     dut_io_pads_qspi0_sck_o_oval  ;
    wire                                     dut_io_pads_qspi0_cs_0_o_oval  ;
    wire                                     dut_io_pads_qspi0_dq_0_i_ival  ;
    wire                                     dut_io_pads_qspi0_dq_0_o_oval  ;
    wire                                     dut_io_pads_qspi0_dq_0_o_oe   ;
    wire                                     dut_io_pads_qspi0_dq_1_i_ival  ;
    wire                                     dut_io_pads_qspi0_dq_1_o_oval  ;
    wire                                     dut_io_pads_qspi0_dq_1_o_oe   ;
    wire                                     dut_io_pads_qspi0_dq_2_i_ival  ;
    wire                                     dut_io_pads_qspi0_dq_2_o_oval  ;
    wire                                     dut_io_pads_qspi0_dq_2_o_oe   ;
    wire                                     dut_io_pads_qspi0_dq_3_i_ival  ;
    wire                                     dut_io_pads_qspi0_dq_3_o_oval  ;
    wire                                     dut_io_pads_qspi0_dq_3_o_oe   ;


    wire                                     dut_io_pads_aon_erst_n_i_ival  ;
    wire                                     dut_io_pads_aon_pmu_dwakeup_n_i_ival  ;
    wire                                     dut_io_pads_aon_pmu_vddpaden_o_oval  ;
    wire                                     dut_io_pads_aon_pmu_padrst_o_oval  ;
    wire                                     dut_io_pads_bootrom_n_i_ival  ;
    wire                                     dut_io_pads_dbgmode0_n_i_ival  ;
    wire                                     dut_io_pads_dbgmode1_n_i_ival  ;
    wire                                     dut_io_pads_dbgmode2_n_i_ival  ;
/*


  //=================================================
  // Clock & Reset
    wire                                     clk_8388                      ;
    wire                                     clk_16M                       ;
  


  mmcm ip_mmcm
  (
    .resetn                                  (ck_rst                       ),
    .clk_in1                                 (CLK100MHZ                    ),
    
    .clk_out2                                (clk_16M                      ),// 16 MHz, this clock we set to 16MHz 
    .locked                                  (mmcm_locked                  ) 
  );

    assign                                   ck_rst                       = fpga_rst & mcu_rst;

  */

  // reset_sys ip_reset_sys
  // (
  //   .slowest_sync_clk(clk_16M),
  //   .ext_reset_in(ck_rst), // Active-low
  //   .aux_reset_in(1'b1),
  //   .mb_debug_sys_rst(1'b0),
  //   .dcm_locked(mmcm_locked),
  //   .mb_reset(),
  //   .bus_struct_reset(),
  //   .peripheral_reset(reset_periph),
  //   .interconnect_aresetn(),
  //   .peripheral_aresetn()
  // );

  //=================================================
  // SPI0 Interface

    wire               [   3: 0]             qspi0_ui_dq_o                 ;
    wire               [   3: 0]             qspi0_ui_dq_oe                ;
    wire               [   3: 0]             qspi0_ui_dq_i                 ;

  PULLUP qspi0_pullup[3:0]
  (
    .O                                       (qspi0_dq                     ) 
  );

  IOBUF qspi0_iobuf[3:0]
  (
    .IO                                      (qspi0_dq                     ),
    .O                                       (qspi0_ui_dq_i                ),
    .I                                       (qspi0_ui_dq_o                ),
    .T                                       (~qspi0_ui_dq_oe              ) 
  );


  //=================================================
  // IOBUF instantiation for GPIOs

  IOBUF
  #(
    .DRIVE                                   (12                           ),
    .IBUF_LOW_PWR                            ("TRUE"                       ),
    .IOSTANDARD                              ("DEFAULT"                    ),
    .SLEW                                    ("SLOW"                       ) 
  )
  gpioA_iobuf[31:0]
  (
    .O                                       (dut_io_pads_gpioA_i_ival     ),
    .IO                                      (gpioA                        ),
    .I                                       (dut_io_pads_gpioA_o_oval     ),
    .T                                       (~dut_io_pads_gpioA_o_oe      ) 
  );

  IOBUF
  #(
    .DRIVE                                   (12                           ),
    .IBUF_LOW_PWR                            ("TRUE"                       ),
    .IOSTANDARD                              ("DEFAULT"                    ),
    .SLEW                                    ("SLOW"                       ) 
  )
  gpioB_iobuf[31:0]
  (
    .O                                       (dut_io_pads_gpioB_i_ival     ),
    .IO                                      (gpioB                        ),
    .I                                       (dut_io_pads_gpioB_o_oval     ),
    .T                                       (~dut_io_pads_gpioB_o_oe      ) 
  );
  //=================================================
  // JTAG IOBUFs

    wire                                     iobuf_jtag_TCK_o              ;
  IOBUF
  #(
    .DRIVE                                   (12                           ),
    .IBUF_LOW_PWR                            ("TRUE"                       ),
    .IOSTANDARD                              ("DEFAULT"                    ),
    .SLEW                                    ("SLOW"                       ) 
  )
  IOBUF_jtag_TCK
  (
    .O                                       (iobuf_jtag_TCK_o             ),
    .IO                                      (mcu_TCK                      ),
    .I                                       (1'b0                         ),
    .T                                       (1'b1                         ) 
  );
    assign                                   dut_io_pads_jtag_TCK_i_ival  = iobuf_jtag_TCK_o;
  PULLUP pullup_TCK (.O(mcu_TCK));

    wire                                     iobuf_jtag_TMS_o              ;
  IOBUF
  #(
    .DRIVE                                   (12                           ),
    .IBUF_LOW_PWR                            ("TRUE"                       ),
    .IOSTANDARD                              ("DEFAULT"                    ),
    .SLEW                                    ("SLOW"                       ) 
  )
  IOBUF_jtag_TMS
  (
    .O                                       (iobuf_jtag_TMS_o             ),
    .IO                                      (mcu_TMS                      ),
    .I                                       (1'b0                         ),
    .T                                       (1'b1                         ) 
  );
    assign                                   dut_io_pads_jtag_TMS_i_ival  = iobuf_jtag_TMS_o;
  PULLUP pullup_TMS (.O(mcu_TMS));

    wire                                     iobuf_jtag_TDI_o              ;
  IOBUF
  #(
    .DRIVE                                   (12                           ),
    .IBUF_LOW_PWR                            ("TRUE"                       ),
    .IOSTANDARD                              ("DEFAULT"                    ),
    .SLEW                                    ("SLOW"                       ) 
  )
  IOBUF_jtag_TDI
  (
    .O                                       (iobuf_jtag_TDI_o             ),
    .IO                                      (mcu_TDI                      ),
    .I                                       (1'b0                         ),
    .T                                       (1'b1                         ) 
  );
    assign                                   dut_io_pads_jtag_TDI_i_ival  = iobuf_jtag_TDI_o;
  PULLUP pullup_TDI (.O(mcu_TDI));

    wire                                     iobuf_jtag_TDO_o              ;
  IOBUF
  #(
    .DRIVE                                   (12                           ),
    .IBUF_LOW_PWR                            ("TRUE"                       ),
    .IOSTANDARD                              ("DEFAULT"                    ),
    .SLEW                                    ("SLOW"                       ) 
  )
  IOBUF_jtag_TDO
  (
    .O                                       (iobuf_jtag_TDO_o             ),
    .IO                                      (mcu_TDO                      ),
    .I                                       (dut_io_pads_jtag_TDO_o_oval  ),
    .T                                       (~dut_io_pads_jtag_TDO_o_oe   ) 
  );

  //wire iobuf_jtag_TRST_n_o;
  //IOBUF
  //#(
  //  .DRIVE(12),
  //  .IBUF_LOW_PWR("TRUE"),
  //  .IOSTANDARD("DEFAULT"),
  //  .SLEW("SLOW")
  //)

  //=================================================
  // Assignment of IOBUF "IO" pins to package pins

  // Pins IO0-IO13
  // Shield header row 0: PD0-PD7

  // Use the LEDs for some more useful debugging things.
    assign                                   pmu_paden                    = dut_io_pads_aon_pmu_vddpaden_o_oval;
    assign                                   pmu_padrst                   = dut_io_pads_aon_pmu_padrst_o_oval;

  // model select
    assign                                   dut_io_pads_bootrom_n_i_ival = 1'b1;//
    assign                                   dut_io_pads_dbgmode0_n_i_ival= 1'b1;
    assign                                   dut_io_pads_dbgmode1_n_i_ival= 1'b1;
    assign                                   dut_io_pads_dbgmode2_n_i_ival= 1'b1;
  //

  e203_soc_top dut
  (
    .hfextclk                                (clk_16M                      ),
    .hfxoscen                                (                             ),

    .lfextclk                                (CLK32768KHZ                  ),
    .lfxoscen                                (                             ),

       // Note: this is the real SoC top AON domain slow clock
    .io_pads_jtag_TCK_i_ival                 (dut_io_pads_jtag_TCK_i_ival  ),
    .io_pads_jtag_TMS_i_ival                 (dut_io_pads_jtag_TMS_i_ival  ),
    .io_pads_jtag_TDI_i_ival                 (dut_io_pads_jtag_TDI_i_ival  ),
    .io_pads_jtag_TDO_o_oval                 (dut_io_pads_jtag_TDO_o_oval  ),
    .io_pads_jtag_TDO_o_oe                   (dut_io_pads_jtag_TDO_o_oe    ),

    .io_pads_gpioA_i_ival                    (dut_io_pads_gpioA_i_ival     ),
    .io_pads_gpioA_o_oval                    (dut_io_pads_gpioA_o_oval     ),
    .io_pads_gpioA_o_oe                      (dut_io_pads_gpioA_o_oe       ),

    .io_pads_gpioB_i_ival                    (dut_io_pads_gpioB_i_ival     ),
    .io_pads_gpioB_o_oval                    (dut_io_pads_gpioB_o_oval     ),
    .io_pads_gpioB_o_oe                      (dut_io_pads_gpioB_o_oe       ),

    .io_pads_qspi0_sck_o_oval                (dut_io_pads_qspi0_sck_o_oval ),
    .io_pads_qspi0_cs_0_o_oval               (dut_io_pads_qspi0_cs_0_o_oval),

    .io_pads_qspi0_dq_0_i_ival               (dut_io_pads_qspi0_dq_0_i_ival),
    .io_pads_qspi0_dq_0_o_oval               (dut_io_pads_qspi0_dq_0_o_oval),
    .io_pads_qspi0_dq_0_o_oe                 (dut_io_pads_qspi0_dq_0_o_oe  ),
    .io_pads_qspi0_dq_1_i_ival               (dut_io_pads_qspi0_dq_1_i_ival),
    .io_pads_qspi0_dq_1_o_oval               (dut_io_pads_qspi0_dq_1_o_oval),
    .io_pads_qspi0_dq_1_o_oe                 (dut_io_pads_qspi0_dq_1_o_oe  ),
    .io_pads_qspi0_dq_2_i_ival               (dut_io_pads_qspi0_dq_2_i_ival),
    .io_pads_qspi0_dq_2_o_oval               (dut_io_pads_qspi0_dq_2_o_oval),
    .io_pads_qspi0_dq_2_o_oe                 (dut_io_pads_qspi0_dq_2_o_oe  ),
    .io_pads_qspi0_dq_3_i_ival               (dut_io_pads_qspi0_dq_3_i_ival),
    .io_pads_qspi0_dq_3_o_oval               (dut_io_pads_qspi0_dq_3_o_oval),
    .io_pads_qspi0_dq_3_o_oe                 (dut_io_pads_qspi0_dq_3_o_oe  ),


       // Note: this is the real SoC top level reset signal
    .io_pads_aon_erst_n_i_ival               (ck_rst                       ),
    .io_pads_aon_pmu_dwakeup_n_i_ival        (dut_io_pads_aon_pmu_dwakeup_n_i_ival),
    .io_pads_aon_pmu_vddpaden_o_oval         (dut_io_pads_aon_pmu_vddpaden_o_oval),

    .io_pads_aon_pmu_padrst_o_oval           (dut_io_pads_aon_pmu_padrst_o_oval),

    .io_pads_bootrom_n_i_ival                (dut_io_pads_bootrom_n_i_ival ),

    .io_pads_dbgmode0_n_i_ival               (dut_io_pads_dbgmode0_n_i_ival),
    .io_pads_dbgmode1_n_i_ival               (dut_io_pads_dbgmode1_n_i_ival),
    .io_pads_dbgmode2_n_i_ival               (dut_io_pads_dbgmode2_n_i_ival) 
  );

  // Assign reasonable values to otherwise unconnected inputs to chip top

    wire                                     iobuf_dwakeup_o               ;
  IOBUF
  #(
    .DRIVE                                   (12                           ),
    .IBUF_LOW_PWR                            ("TRUE"                       ),
    .IOSTANDARD                              ("DEFAULT"                    ),
    .SLEW                                    ("SLOW"                       ) 
  )
  IOBUF_dwakeup_n
  (
    .O                                       (iobuf_dwakeup_o              ),
    .IO                                      (mcu_wakeup                   ),
    .I                                       (1'b1                         ),
    .T                                       (1'b1                         ) 
  );
    assign                                   dut_io_pads_aon_pmu_dwakeup_n_i_ival= (~iobuf_dwakeup_o);

  

    assign                                   dut_io_pads_aon_pmu_vddpaden_i_ival= 1'b1;

    assign                                   qspi0_sck                    = dut_io_pads_qspi0_sck_o_oval;
    assign                                   qspi0_cs                     = dut_io_pads_qspi0_cs_0_o_oval;
  assign qspi0_ui_dq_o = {
    dut_io_pads_qspi0_dq_3_o_oval,
    dut_io_pads_qspi0_dq_2_o_oval,
    dut_io_pads_qspi0_dq_1_o_oval,
    dut_io_pads_qspi0_dq_0_o_oval
  };
  assign qspi0_ui_dq_oe = {
    dut_io_pads_qspi0_dq_3_o_oe,
    dut_io_pads_qspi0_dq_2_o_oe,
    dut_io_pads_qspi0_dq_1_o_oe,
    dut_io_pads_qspi0_dq_0_o_oe
  };
    assign                                   dut_io_pads_qspi0_dq_0_i_ival= qspi0_ui_dq_i[0];
    assign                                   dut_io_pads_qspi0_dq_1_i_ival= qspi0_ui_dq_i[1];
    assign                                   dut_io_pads_qspi0_dq_2_i_ival= qspi0_ui_dq_i[2];
    assign                                   dut_io_pads_qspi0_dq_3_i_ival= qspi0_ui_dq_i[3];



endmodule


